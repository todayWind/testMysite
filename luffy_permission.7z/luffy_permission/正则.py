import re
print(re.match('^/customer/list/$','/customer/list/aaaa'))