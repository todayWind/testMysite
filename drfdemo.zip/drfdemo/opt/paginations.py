from rest_framework.pagination import LimitOffsetPagination, PageNumberPagination

# 自定义分页器，PageNumberPagination
class StudentPageNumberPagination(PageNumberPagination):
    page_query_param = "page" # 查询字符串中代表页码的变量名
    page_size_query_param = "size" # 查询字符串中代表每一页数据的变量名
    page_size = 10       # 每一页的数据量
    max_page_size = 100  # 允许客户端通过查询字符串调整的最大单页数据量