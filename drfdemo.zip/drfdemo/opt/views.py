from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from rest_framework.views import APIView
from rest_framework.response import Response
from drfdemo.authentication import CustomAuthentication

class ExampleView(APIView):
    # 类属性
    # authentication_classes = [CustomAuthentication]

    def get(self,request):
        print(request.user)  # 未登录用户：AnonymousUser
        if request.user.id:
            print("通过认证")
        else:
            print("未通过认证")
        return Response({"msg":"ok"})


class HomeAPIView(APIView):
    authentication_classes = [SessionAuthentication, BasicAuthentication]
    def get(self,request):
        print(request.user)  # 未登录用户：AnonymousUser
        if request.user.id:
            print("通过认证")
        else:
            print("未通过认证")
        return Response({"msg":"ok"})


from rest_framework.permissions import IsAuthenticated, IsAdminUser, IsAuthenticatedOrReadOnly
from drfdemo.permissions import IsXiaoMingPermission
from school.models import Student

class HomeInfoAPIView(APIView):
    # 内置权限
    # permission_classes = [IsAuthenticated]  # 表示当前视图类中的所有视图方法，只能被已经登录的站点会员访问
    # permission_classes = [IsAdminUser]  # 表示当前视图类中的所有视图方法，只能被已经登录的站点站点管理员访问操作，user.is_staff为True
    # permission_classes = [IsAuthenticatedOrReadOnly]  # 表示当前视图类中的所有视图方法，游客只能查看数据，已经登录认证的用户则可以对数据进行任意操作
    # 自定义权限
    permission_classes = [IsXiaoMingPermission]
    def get(self,request):
        return Response({"msg": "ok"})

    def post(self,request):
        return Response({"msg": "ok"})

from rest_framework.generics import RetrieveAPIView
from rest_framework.throttling import UserRateThrottle
from school.serializers import Student3ModelSerializer


class StudentInfoAPIView(RetrieveAPIView):
    queryset = Student.objects.all()
    serializer_class = Student3ModelSerializer
    permission_classes = [IsAuthenticated]

    # 限流局部配置[这里需要配合在全局配置中的DEFAULT_THROTTLE_RATES来设置频率]
    throttle_classes = [UserRateThrottle]


class Demo1APIView(APIView):
    """自定义限流"""
    permission_classes = [IsAuthenticated]
    throttle_scope = "member"
    def get(self,request):
        return Response({"msg": "ok"})

class Demo2APIView(APIView):
    """自定义限流"""
    permission_classes = [IsAuthenticated]
    throttle_scope = "vip"
    def get(self,request):
        return Response({"msg": "ok"})

class Demo3APIView(APIView):
    """自定义限流"""
    permission_classes = [IsAuthenticated]
    throttle_scope = "vvip"
    def get(self,request):
        return Response({"msg": "ok"})


from rest_framework.generics import ListCreateAPIView
from stuapi.models import Student
from students.serializers import Student2ModelSerializer
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import OrderingFilter
class Demo4APIView(ListCreateAPIView):
    queryset = Student.objects.all()
    serializer_class = Student3ModelSerializer
    # 局部配置[过滤]
    # filter_backends = [DjangoFilterBackend]
    filter_fields = ["sex","classmate"]

    # 局部配置[排序]
    # filter_backends = [OrderingFilter]
    ordering_fields = ['id', 'age']

    # 局部配置[过滤和排序一起使用]
    filter_backends = [DjangoFilterBackend, OrderingFilter]


from rest_framework.generics import ListAPIView
from .paginations import StudentPageNumberPagination

class Demo5APIView(ListAPIView):
    queryset = Student.objects.all()
    serializer_class = Student3ModelSerializer

    # 关闭来自全局配置中的分页信息
    # pagination_class = None


    # 局部配置分页功能
    pagination_class = StudentPageNumberPagination


class Demo6APIView(APIView):
    def get(self,request):
        1/0
        return Response({"msg":"ok"})