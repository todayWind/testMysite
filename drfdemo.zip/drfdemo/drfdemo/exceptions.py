from rest_framework.views import exception_handler as drf_exception_handler
from rest_framework.response import Response
from django.db import DataError

def custom_exception_handler(exc, context):
    """
    自定义异常函数
    :exc 本次发生的异常对象，对象
    :context 本次发生异常时的上下文环境信息，字典
             所谓的执行上下文就是python解释器在执行代码时保存在内存中的变量、函数、类、对象、模块等一系列的信息组成的环境信息。
    """
    # 先让drf把自己能处理的异常，先处理完成
    response = drf_exception_handler(exc, context)
    # 如果返回值是None，则当前异常是drf无法处理的，就需要我们自己编写处理异常的代码逻辑了。
    if response is None:
        """当前发生的异常，drf没有进行处理"""
        if isinstance(exc, ZeroDivisionError):
            response = Response({"detail": "0不能作为除数！"})

        if isinstance(exc, DataError):
            response = Response({"detail": "数据存储异常！"})

    return response