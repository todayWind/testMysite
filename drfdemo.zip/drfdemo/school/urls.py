from django.urls import path
from rest_framework.routers import SimpleRouter
from . import views

router = SimpleRouter()
router.register("students", views.StudentModelViewSet, basename="students")

urlpatterns = [

] + router.urls

