from rest_framework import serializers

from school.models import Student, Achievement, Course

class CourseModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Course
        fields = ["name"]

class AchievementModelSerializer(serializers.ModelSerializer):
    # course = CourseModelSerializer()
    course_name = serializers.CharField(source="course.name")
    teacher_name = serializers.CharField(source="course.teacher.name")

    class Meta:
        model = Achievement
        fields = ["id", "course_name", "teacher_name", "score", "create_dtime"]

class AchievementModelSerializer2(serializers.ModelSerializer):
    class Meta:
        model = Achievement
        # 指定关联深度
        # 从成绩模型->课程 = 1
        # 从成绩模型->课程->老师 = 2
        fields = "__all__"
        depth = 3

class Student3ModelSerializer(serializers.ModelSerializer):
    # s_achievment = AchievementModelSerializer2(many=True)  # s_achievment 就是模型中声明的外键字段，非外键字段不能指定序列化器对象
    class Meta:
        model = Student
        fields = ["id", "name", "achievement"]