from rest_framework.viewsets import ModelViewSet
from .models import Student
from .serializers import Student3ModelSerializer
# Create your views here.

class StudentModelViewSet(ModelViewSet):
    queryset = Student.objects.all()
    serializer_class = Student3ModelSerializer
