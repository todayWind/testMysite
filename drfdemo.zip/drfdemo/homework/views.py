from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serialziers import CourseModelSerialzier
from .models import Course
# Create your views here.


class CourseAPIView(APIView):
    def get(self,request):
        """获取所有课程信息"""
        # 1. 从模型中获取所有数据
        queryset = Course.objects.all()
        # 2. 序列化
        serializer = CourseModelSerialzier(queryset, many=True)

        # 3. 返回结果
        return Response(serializer.data)

    def post(self,request):
        """添加一条数据"""
        # 接收客户端提交的数据
        data = request.data
        # 反序列化[验证数据，保存数据]
        serializer = CourseModelSerialzier(data=data)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        # 返回结果
        return Response(serializer.data, status=status.HTTP_201_CREATED)

"""
{
  "name": "python入门",
  "description": "生动有趣的python入门课程。。。。。。。。。。",
  "ontime": "9:30:00",
  "outtime": "12:30:00",
  "duration": 90,
  "price": 3999
}
"""

class CourseInfoAPIView(APIView):
    def get(self,request, pk):
        """获取一个课程信息"""
        # 根据PK获取模型对象
        try:
            instance = Course.objects.get(pk=pk)
        except Course.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)

        # 序列化
        serializer = CourseModelSerialzier(instance=instance)

        # 返回结果
        return Response(serializer.data)

    def put(self,request, pk):
        # 根据PK获取模型对象
        try:
            instance = Course.objects.get(pk=pk)
        except Course.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)

        # 获取客户端提交数据，反序列化
        serializer = CourseModelSerialzier(instance=instance, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        # 返回结果
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def delete(self,request, pk):
        # 根据PK获取模型对象
        try:
            instance = Course.objects.get(pk=pk)
        except Course.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)

        instance.delete()

        # 返回结果
        return Response(status=status.HTTP_204_NO_CONTENT)