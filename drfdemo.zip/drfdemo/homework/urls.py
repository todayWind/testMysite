from django.urls import path, re_path
from . import views

urlpatterns = [
    path("courses/", views.CourseAPIView.as_view()),
    re_path("^courses/(?P<pk>\d+)/$", views.CourseInfoAPIView.as_view()),
]