from django.views import View
from django.http.response import HttpResponse
from rest_framework.views import APIView
from rest_framework.response import Response  # drf的Response对象是django的HttpResponse的子类
from rest_framework import status  # 保存了所有的HTTP响应状态对应的常量
# Create your views here.

# 路由--->视图类->as_view()  ---> setup ---> 调用了父类的方法---> request对象
class StudentView(View):
    def get(self,request):  # django提供的View视图，在视图方法中传入的request变量是 WSGIHttpRequest
        print(f"request={request}")  # WSGIHttpRequest---> 父类 --> django.http.request.HttpRequest
        return HttpResponse("ok")

class StudentAPIView(APIView):
    def get(self,request):
        # rest_framework.request.Request 是属于drf单独声明的请求处理对象，与django提供的HttpRequest不是同一个，甚至没有任何的继承关系
        print(f"drf.request={request}")
        print(f"django.request={request._request}") # WSGIHttpRequest

        """获取查询参数/查询字符串"""
        print(f"request.query_params={request.query_params}")
        response = Response({"msg":"ok"}, status=status.HTTP_201_CREATED, headers={"Company": "Python36"} )
        return response
        # return HttpResponse("ok")

    def post(self,request):
        # 添加数据
        """获取请求体数据"""
        print(f"request.data={request.data}")  # 接收的数据已经被Parse解析器转换成字典数据了。
        # 客户端提交json数据
        # request.data={'name': 'xiaoming', 'password': '123456'}
        # 客户端提交表单数据
        # request.data=<QueryDict: {'name': ['xiaoming'], 'password': ['123456'], 'sex': ['1']}>
        print(request.data.get("name"))

        """获取查询参数/查询字符串"""
        print(f"request.query_params={request.query_params}")

        return Response({"msg":"ok"})

    def put(self,request):
        # 更新数据
        return Response({"msg": "ok"})

    def patch(self,request):
        # 更新数据[部分]
        return Response({"msg": "ok"})


    def delete(self,request):
        # 删除操作
        return Response({"msg": "ok"})
